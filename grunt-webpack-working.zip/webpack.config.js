var path = require('path');
var ExtractTextPlugin = require('extract-text-webpack-plugin');
var HtmlWebpackPlugin = require('html-webpack-plugin');

var config = {
  source: './app',
  destination: './dist'
};

module.exports = {
  entry: [ config.source + '/js/index.js', config.source + '/scss/main.scss'],
  output: {
    filename: 'js/bundle.js',
    path: path.resolve(__dirname, 'dist')
  },

  module: {
    rules: [
      /*
      your other rules for JavaScript transpiling go in here
      */
      { // regular css files
        test: /\.css$/,
        loader: ExtractTextPlugin.extract({
          loader: 'css-loader?importLoaders=1',
        }),
      },
      { // sass / scss loader for webpack
        test: /\.(sass|scss)$/,
        loader: ExtractTextPlugin.extract(['css-loader', 'sass-loader'])
      }
    ]
  },

  plugins: [
    new ExtractTextPlugin({
      filename: 'css/main.bundle.css',
      allChunks: true
    }),
    new HtmlWebpackPlugin()
  ],

  cache: false,
  // watch: true,
  watchOptions: {
    aggregateTimeout: 1000,
    poll: true,
    poll: 500
  }
};